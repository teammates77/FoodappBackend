package com.Userservice.DTO;

import lombok.Data;

@Data
public class ResponseDTO {

		private String statusCode;
		private String statusMsg;
}